import pickle
import numpy as np
from munkres import Munkres
import json

def compare(b1, b2):
    """
    b1 = (x, y, w, h)
    b2 = (x, y, w, h)
    Cette fonction calcule une vraisemblance sur entre les bounding box b1 et b2
    La valeur de retour doit être élevée si ces deux détections appartiennent au même objet
    Fonction à remplir

    """
    ### votre code ici
    return None 


def get_m(bb1, bb2):
    m = np.zeros((len(bb1), len(bb2)))
    for i, b1 in enumerate(bb1):
        for j, b2 in enumerate(bb2):
            m[i,j] = -compare(b1, b2)
    return m

def get_association(bb1, bb2):
    mat = get_m(bb1, bb2)
    m = Munkres()
    indexes = m.compute(mat.transpose())
    indexes = [(j, i) for (i,j) in indexes ]
    return indexes

n_o = 5
json_file = "/home/paul/data/eisti/Image_processing_geometry/yolo_detections.json"
results = json.load(open(json_file))
sorted_imgs = sorted(results.keys())
(bbox, conf, idclass) = results[sorted_imgs[0]]
tracks = [  [ box ]  for  (i, box) in enumerate(bbox)  if idclass[i]=='bottle' ]
imgPaths = []
tracking = {}
for imgPath  in sorted_imgs[1:]:
    (bbox, conf, idclass) =  results[imgPath]
    bottles = [ box  for (i,box) in enumerate(bbox)  if idclass[i]=='bottle' ]
    if len(bottles) > n_o:
        print("too many bottles",imgPath)
        continue
    last_bottles = [t[-1] for t in tracks]
    indices = get_association(last_bottles, bottles)
    tracking[imgPath] = []
    for i,j in indices:
        tracks[i].append(bottles[j])
        (x1, y1, w, h) = bottles[j]
        tracking[imgPath].append((i, (x1, y1, w, h)))

json.dump(tracking, open("tracking.json","w"))
