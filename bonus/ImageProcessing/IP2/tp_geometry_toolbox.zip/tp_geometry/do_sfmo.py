import json
import numpy as np
from tp_geometry import sfmo
from tp_geometry import utils


# lire les résultats du tracking
tracking = json.load(open('tracking.json','r'))
n_o = 5 # I put 5 bottles on the table
n_f = len(tracking) # number of frames


# Construire une ellipse pour chaque boite englobantes et stocker les résultats dans une matrice C
C = np.zeros((n_f*3, n_o*3))
f = 0
for (imgPath,dets) in tracking.items():
    if len(dets) != n_o:
        continue # we don't deal with missing values
    for (trackid, (x, y, w, h)) in dets:
        c = sfmo.bbx2ell((x, y, w, h))
        C[f*3:f*3+3, trackid*3:trackid*3+3] = c
    f += 1
C = C[:3*f]

#Vectoriser les differents composants de cette matrice: (n_f*3, n_o*3) -> (nf_*6, n_o)
Cadjv_mat = utils.conics_to_vec(C, norm=True)

# Effectuer la reconstuction des quadriques
Rec = sfmo.sfmo(Cadjv_mat)
# Les convertir en ellipsoides
ells = utils.quadrics2ellipsoids(Rec)
# Afficher le résultat
utils.plot_ellipsoids(ells)
