from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
import numpy as np
from tp_geometry import utils
from tp_geometry import gen_synth


def get_min_max(ells, cameras):
    greatest_axes = max([max(ell['axes']) for ell in ells])
    max_ex, min_ex = max([ell['C'][0] for ell in ells]), min([ell['C'][0] for ell in ells])
    max_cx, min_cx = max([camera[0, :].max() for camera in cameras]), min([camera[0, :].min() for camera in cameras])
    max_x, min_x = max(max_cx, max_ex), min(min_cx, min_ex)

    max_ey, min_ey = max([ell['C'][1] for ell in ells]), min([ell['C'][1] for ell in ells])
    max_cy, min_cy = max([camera[1, :].max() for camera in cameras]), min([camera[1, :].min() for camera in cameras])
    max_y, min_y = max(max_cy, max_ey), min(min_cy, min_ey)

    max_ez, min_ez = max([ell['C'][2] for ell in ells]), min([ell['C'][2] for ell in ells])
    max_cz, min_cz = max([camera[2, :].max() for camera in cameras]), min([camera[2, :].min() for camera in cameras])
    max_z, min_z = max(max_cz, max_ez), min(min_cz, min_ez)
    return min_x - greatest_axes, min_y - greatest_axes, min_z - greatest_axes, max_x + greatest_axes, max_y + greatest_axes, max_z + greatest_axes


def get_min_max_c(ells_f):
    greatest_axes = max([max(e.width, e.height) for e in ells_f])
    max_x, max_y = max([e.center[0] for e in ells_f]), max([e.center[1] for e in ells_f])
    min_x, min_y = min([e.center[0] for e in ells_f]), min([e.center[1] for e in ells_f])
    return min_x - greatest_axes, min_y - greatest_axes, max_x + greatest_axes, max_y + greatest_axes


def plot_ellipsoids(Q, save_to=None, colors=None, keep_alive=True):
    ells = utils.quadrics2ellipsoids(Q)
    n_o = len(ells)
    if colors is None:
        colors = np.random.rand(n_o, 3)
    #fig = plt.figure(figsize=plt.figaspect(1))  # Square figure
    fig = plt.figure(1)  # Square figure
    ax = fig.add_subplot(111, projection='3d')
    #plotting the ellipsoids
    for (o, ell) in enumerate(ells):
        x, y, z = utils.get_ellipsoid_pc(ell)
        #Plot: 
        ax.plot_surface(x, y, z,  rstride=4, cstride=4, color=colors[o, :])
    if save_to ==None:
        if keep_alive:
            plt.show()
        else:
            fig.show()
    else:
        plt.savefig(save_to)

def plot_ellipses(C, save_to=None, colors=None, keep_alive=True):
    #getting the ellipses
    ells = utils.get_ellipses(C)
    n_o = len(ells[0])  # guessing the number of objects from the first frame
    #plotting the ellipses
    if colors is None:
        colors = np.random.rand(n_o, 3)
    for n_f, ells_f in ells.items():
        fig2 = plt.figure(2)
        ax2 = fig2.add_subplot(111, aspect='equal')
        for o, e in enumerate(ells_f):
            ax2.add_artist(e)
            e.set_clip_box(ax2.bbox)
            e.set_alpha(0.5)
            e.set_facecolor(color=colors[o, :])
            min_x, min_y, max_x, max_y = get_min_max_c(ells_f)
            getattr(ax2, 'set_{}lim'.format('x'))((min_x, max_x))
            getattr(ax2, 'set_{}lim'.format('y'))((min_y, max_y))
        break # just print one frame, but I could do more
    if save_to ==None:
        if keep_alive:
            plt.show()
        else:
            fig2.show()
    else:
        plt.savefig(save_to)


