public class Exo2{

   private static char countMaxCar(String input ) {
       Map<Character, Integer> charMap = new HashMap <> ();
       
    }
}