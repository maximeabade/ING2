import org.junit.jupiter.api.*;

import java.util.*;

public class TestTD2 {

    private TD2 t;

    @BeforeAll
    private static void start(){
        System.out.println("START");
    }

    @AfterAll
    private static void end(){
        System.out.println("END");
    }

    @BeforeEach
    private void start_test(){
        System.out.println("New Test");
        t = new TD2();
    }

    @AfterEach
    private void end_test(){
        System.out.println("End Test");
        t = null;
    }


    @Test
    @DisplayName("toz")
    private void test_empty(){
        System.out.println("toz le retour");
        Assertions.assertEquals(new int[]{}, t.triBicolore( new int[]{}), "Bah non du coup" );
    }

}