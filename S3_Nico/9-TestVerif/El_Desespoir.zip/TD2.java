import java.util.*;



public class TD2{
	
	static int[] triBicolore(int[] t) {
		int i;
		int izero;
		i = 0;
		izero = t.length-1;
		
		while (i<izero) {
			System.out.println("boucle while");
			if (t[i] == 0) {
				while (t[izero] == 0) {
					izero--;
				}
				t[i] = t[izero];
				t[izero] = 0;
				izero --;
			}
			
			i++;
		}
		return t;
	}
	
}


