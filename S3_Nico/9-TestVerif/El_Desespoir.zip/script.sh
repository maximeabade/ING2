javac -d out TD2.java
javac -d out -cp junit-platform-console-standalone-1.8.1.jar:out TestTD2.java
java -jar junit-platform-console-standalone-1.8.1.jar -cp out --scan-classpath
